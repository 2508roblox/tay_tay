export default function LightGalleryModule() {
    jQuery("#lightgallery").lightGallery({
        selector: '.lightgallery-selector',
        thumbnail: true,
    });
}